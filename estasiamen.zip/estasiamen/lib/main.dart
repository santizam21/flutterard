// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter_blue/flutter_blue.dart' as flutter_blue;
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bluetooth Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  FlutterBlue flutterBlue = FlutterBlue.instance;
  late flutter_blue.BluetoothDevice selectedDevice;
  late BluetoothCharacteristic characteristic;

  @override
  void initState() {
    super.initState();
    initBluetooth();
  }

  void initBluetooth() async {
    await flutterBlue.startScan(timeout: const Duration(seconds: 4));
    flutterBlue.scanResults.listen((results) {
      for (ScanResult result in results) {
        // ignore: avoid_print
        print('Discovered device: ${result.device.name}');
        // Aquí puedes filtrar los dispositivos por nombre o ID si es necesario
      }
    });
  }

  void connectToDevice() async {
    // Puedes conectar al dispositivo seleccionado aquí
    // Ejemplo:
    // await selectedDevice.connect();
    // var services = await selectedDevice.discoverServices();
    // services.forEach((service) {
    //   var characteristics = service.characteristics;
    //   characteristics.forEach((characteristic) {
    //     // Aquí puedes buscar la característica que necesitas para la comunicación
    //     // characteristic puede ser comparada por UUID para encontrar la correcta
    //   });
    // });
  }

  void sendData(String data) {
    // Puedes enviar datos al dispositivo conectado aquí
    // Ejemplo:
    // characteristic.write(utf8.encode(data));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bluetooth Demo'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                // Aquí puedes abrir una ventana emergente para seleccionar el dispositivo Bluetooth
                // o puedes implementar tu propio método para seleccionar el dispositivo
                setState(() {
                  // Aquí deberías asignar el dispositivo seleccionado
                  // selectedDevice = ...
                });
              },
              child: const Text('Seleccionar Dispositivo Bluetooth'),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    sendData('1');
                  },
                  child: const Text('ON'),
                ),
                ElevatedButton(
                  onPressed: () {
                    sendData('2');
                  },
                  child: const Text('OFF'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
